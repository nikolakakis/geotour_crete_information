<?php
// admin/admin-settings.php
/**
* Add a top-level menu page.
*/
function geotour_plugin_menu() {
  add_menu_page(
    'Geotour Crete Information', // Page title
    'Geotour Crete', // Menu title
    'manage_options', // Capability required to access the page
    'geotour-crete-information', // Menu slug
    'geotour_plugin_options_page', // Callback function to render the page
    'dashicons-location-alt', // Icon (using Dashicons)
    20 // Position (adjust as needed)
  );
}
add_action('admin_menu', 'geotour_plugin_menu');

/**
* Enqueue admin scripts and styles.
*/
add_action('admin_enqueue_scripts', 'geotour_admin_enqueue_scripts');
function geotour_admin_enqueue_scripts($hook) {
      if ('toplevel_page_geotour-crete-information' === $hook) {
        wp_enqueue_style('leaflet-css', 'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css', array(), '1.9.4');
        wp_enqueue_script('leaflet-js', 'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js', array(), '1.9.4', true);
        
        $wizard_js_ver = filemtime(plugin_dir_path(__FILE__) . 'js/shortcode-wizard.js');
        $admin_css_ver = filemtime(plugin_dir_path(__FILE__) . 'css/admin-styles.css');
        $build_js_ver = filemtime(plugin_dir_path(__FILE__) . '../build/index.js');
        $build_css_ver = filemtime(plugin_dir_path(__FILE__) . '../build/index.css');

        wp_enqueue_script('geotour-shortcode-wizard', plugin_dir_url(__FILE__) . 'js/shortcode-wizard.js', array('jquery', 'leaflet-js'), $wizard_js_ver, true);
        wp_enqueue_style('geotour-admin-styles', plugin_dir_url(__FILE__) . 'css/admin-styles.css', array(), $admin_css_ver);
        wp_enqueue_script('geotour-index', plugin_dir_url(__FILE__) . '../build/index.js', array('jquery'), $build_js_ver, true);
        wp_enqueue_style('geotour-index-styles', plugin_dir_url(__FILE__) . '../build/index.css', array(), $build_css_ver);
    
        $default_lat = get_option('geotour_default_lat', '35.035557');
            $default_lon = get_option('geotour_default_lon', '24.789770');

        // No API key here — it stays server-side (geotour_fetch_listings_proxy(),
        // includes/api.php) and is never sent to the browser. restUrl points the
        // wizard's live preview at that local proxy instead of building a
        // geotour.gr URL with the key baked into it.
        wp_localize_script('geotour-shortcode-wizard', 'geotourSettings', array(
          'restUrl' => rest_url('geotour/v1/listings'),
          'nonce' => wp_create_nonce('geotour_set_default_location'),
                'defaultLat' => $default_lat,
                'defaultLon' => $default_lon
        ));
    
            // Real defaults, matching events-tab.php's own static preview markup
            // (35.2/25.1/10/12) — an empty object here (the previous "temporary
            // fix") stopped the hard ReferenceError but left lat/lon/radius as
            // undefined, so events.js's haversine check always evaluated to NaN
            // (silently false) and the admin preview permanently showed "No
            // events found" instead of ever actually rendering anything. Real
            // values let the already-working proxy-backed EVENTS class populate
            // this preview for real, same as it does on the public shortcode.
            wp_localize_script('geotour-index', 'geotourEventsParams', array(
                'lat' => '35.2',
                'lon' => '25.1',
                'radius' => '10',
                'max-items' => '12',
            ));
      }
    }

/**
* Callback function to render the plugin options page.
*/
function geotour_plugin_options_page() {
  $api_key = get_option('geotour_api_key');
  $default_lat = get_option('geotour_default_lat', '35.035557');
  $default_lon = get_option('geotour_default_lon', '24.789770');

  ?>
  <div class="wrap">
    <div class="geotour-plugin-header" style="text-align: center; margin-bottom: 20px;">
      <img src="<?php echo plugins_url('../banner-772x250.png', __FILE__); ?>" alt="Geotour Crete Sharing Plugin Banner" style="max-width: 100%; height: auto;">
      <h1 style="margin-top: 10px;">Geotour Crete Sharing Plugin</h1>
    </div>

    <div class="geotour-plugin-notice" style="border: 1px solid #31708f; background-color: #d9edf7; color: #31708f; padding: 10px; margin-bottom: 20px;">
      <p><em>You will need to obtain a valid API key from Geotour website. The API key is unique to a certain domain name. So if you have multiple domain names you will need multiple API keys.</em></p>
      <p>For more information about using this plugin, please visit: <a href="https://www.geotour.gr/about-geotour/geotour-share-plugin/" target="_blank">https://www.geotour.gr/about-geotour/geotour-share-plugin/</a></p>
    </div>

    <form method="post" action="options.php">
      <?php
      settings_fields('geotour_plugin_settings_group');
      do_settings_sections('geotour-crete-information');
      submit_button();
      ?>
    </form>

    <div class="nav-tab-wrapper">
      <a href="#information-tab" id="information-tab-link" class="nav-tab nav-tab-active">Information Shortcode</a>
      <a href="#events-tab" id="events-tab-link" class="nav-tab">Events Shortcode</a>
    </div>

    <div id="information-tab" class="tab-content">
      <?php include(plugin_dir_path(__FILE__) . 'partials/information-tab.php'); ?>
    </div>

    <div id="events-tab" class="tab-content">
      <?php include(plugin_dir_path(__FILE__) . 'partials/events-tab.php'); ?>
    </div>
  </div>
  <?php
}

/**
 * Languages geotour.gr can return Information (listings) content in. A new
 * language on the geotour.gr side (see geotour-translate/includes/class-gt-language.php)
 * doesn't automatically appear here — add it to this list once it's live
 * there, or hook geotour_crete_information_languages to add it without
 * editing this file.
 */
function geotour_crete_information_supported_languages() {
  return apply_filters( 'geotour_crete_information_languages', array(
    'en' => 'English',
    'el' => 'Ελληνικά (Greek)',
    'de' => 'Deutsch (German)',
    'fr' => 'Français (French)',
    'es' => 'Español (Spanish)',
    'nl' => 'Nederlands (Dutch)',
    'pl' => 'Polski (Polish)',
  ) );
}

/**
* Register the API key setting.
*/
function geotour_plugin_settings() {
  register_setting(
    'geotour_plugin_settings_group', // Settings group name
    'geotour_api_key'        // Option name
  );

  // Register new options for default latitude and longitude
  register_setting(
    'geotour_plugin_settings_group',
    'geotour_default_lat'
  );
  register_setting(
    'geotour_plugin_settings_group',
    'geotour_default_lon'
  );

  register_setting(
    'geotour_plugin_settings_group',
    'geotour_content_language'
  );

  add_settings_section(
    'geotour_api_section',      // Section ID
    'API Key Settings',       // Section title
    'geotour_api_section_callback', // Callback function for section content
    'geotour-crete-information'   // Page slug
  );

  add_settings_field(
    'geotour_api_key',        // Field ID
    'API Key',            // Field title
    'geotour_api_key_render',    // Callback function to render the field
    'geotour-crete-information',   // Page slug
    'geotour_api_section'      // Section ID
  );

  add_settings_section(
    'geotour_language_section',
    'Content Language',
    'geotour_language_section_callback',
    'geotour-crete-information'
  );

  add_settings_field(
    'geotour_content_language',
    'Language',
    'geotour_content_language_render',
    'geotour-crete-information',
    'geotour_language_section'
  );
}
add_action('admin_init', 'geotour_plugin_settings');

/**
* Callback function for language section content.
*/
function geotour_language_section_callback() {
  echo '<p>Default language requested from Geotour for the Information (listings) shortcode. Used by any [geotour-information] shortcode that doesn\'t set its own <code>lang</code> attribute — each shortcode can override this individually. Events are always in English for now.</p>';
}

/**
* Callback function to render the language field.
*/
function geotour_content_language_render() {
  $selected = get_option( 'geotour_content_language', 'en' );
  $languages = geotour_crete_information_supported_languages();
  ?>
  <select name="geotour_content_language" id="geotour_content_language">
    <?php foreach ( $languages as $code => $label ) : ?>
      <option value="<?php echo esc_attr( $code ); ?>" <?php selected( $selected, $code ); ?>><?php echo esc_html( $label ); ?></option>
    <?php endforeach; ?>
  </select>
  <?php
}

/**
* Callback function for API key section content.
*/
function geotour_api_section_callback() {
  echo '<p>Enter your Geotour API key to enable information retrieval.</p>';
}

/**
* Callback function to render the API key field.
*/
function geotour_api_key_render() {
  $api_key = get_option('geotour_api_key');
  
  // Perform an authenticated test call in PHP to bypass CORS issues and reliably fetch the header
  $tier_level = 1; // Default
  $privilege_header = '';
  
  if (!empty($api_key)) {
      $test_url = 'https://www.geotour.gr/wp-json/panotours/v2/listings?language=en&lat=35.035557&lon=24.789770&radius=30&category=pois&apikey=' . $api_key;
      $response = wp_remote_head($test_url); // Retrieve headers via HEAD request efficiently
      
      if (!is_wp_error($response)) {
          $privilege_header = wp_remote_retrieve_header($response, 'X-Geotour-Privilege-Level');
          if (!empty($privilege_header)) {
              $tier_level = intval($privilege_header);
          }
      }
  }
  
  ?>
  <input type="text" name="geotour_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" id="geotour_api_key_input" />
  <?php if (!empty($api_key) && !empty($privilege_header)): ?>
      <span id="geotour_api_level_indicator" style="display: inline-flex; align-items: center; margin-left: 10px; padding: 4px 12px; border-radius: 4px; font-size: 13px; color: #fff; background-color: #1d2327; vertical-align: middle;">
          API Level: <strong style="font-size: 18px; font-weight: bold; margin-left: 6px; line-height: 1;"><?php echo esc_html($tier_level); ?></strong>
      </span>
  <?php else: ?>
      <span id="geotour_api_level_indicator" style="display: none; align-items: center; margin-left: 10px; padding: 4px 12px; border-radius: 4px; font-size: 13px; color: #fff; background-color: #1d2327; vertical-align: middle;"></span>
  <?php endif; ?>
  <?php
}

function geotour_set_default_location() {
  check_ajax_referer('geotour_set_default_location');

  if (isset($_POST['lat']) && isset($_POST['lon'])) {
    update_option('geotour_default_lat', sanitize_text_field($_POST['lat']));
    update_option('geotour_default_lon', sanitize_text_field($_POST['lon']));
    wp_send_json_success();
  } else {
    wp_send_json_error();
  }
}
add_action('wp_ajax_geotour_set_default_location', 'geotour_set_default_location');