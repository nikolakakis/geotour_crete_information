=== Geotour Crete Information ===
Contributors: Nikolakakis Manolis
Tags: geotour, crete, tourism, locations, information, shortcode
Banner Image: banner-772x250.png
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.6.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

**Author: Nikolakakis Manolis <nikolakakis.manolis@gmail.com>** 

This plugin enhances WordPress websites with Cretan location details, and other tourist information about Crete by integrating with the Geotour API.

== Description ==

The Geotour Crete Information plugin allows you to easily display information about Crete from the Geotour API on your WordPress website. It uses shortcodes to embed interactive maps, location details, and other tourist information in your posts and pages.

**Features:**

* **Customizable shortcodes:**  Control the output and appearance of the displayed information using shortcode parameters.
* **Admin settings page:** Configure API settings and other plugin options.
* **Responsive design:**  Ensures the information display correctly on all devices.

This plugin is perfect for:

* **Travel blogs and websites:** Enhance your content with engaging and informative maps and location details.
* **Tourism businesses:**  Showcase your services and attractions to potential customers.
* **Anyone who wants to share information about Crete:**  Make it easy for your audience to explore and discover the beauty of Crete.

**More information:**

* **Wiki:** [https://www.geotour.gr](https://www.geotour.gr)

== Installation ==

1. Upload the `geotour-crete-information` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin settings   
 on the Geotour Crete Information admin page.
4. Use the provided shortcodes in your posts and pages to display the information.

== Frequently Asked Questions ==

= How do I use the shortcodes? =
Refer to the plugin's documentation for a complete list of available shortcodes and their parameters.

= Where can I find the plugin documentation? =
You can find the plugin documentation on the plugin's website (add your website URL here).

= Where can I get support for the plugin? =
Please check the plugin page https://www.geotour.gr/about-geotour/geotour-share-plugin/ or contact me from the Geotour page (https://www.geotour.gr/about-geotour/contact/).

== Screenshots ==

1. **Plugin settings page:**
   [screenshot-1.png] 

2. **Map displayed using the plugin's shortcode:**
   [screenshot-2.png]

== Changelog ==
= 1.6.4 =
* Fixed the Information (listings) shortcode calling geotour.gr twice per page load instead of once.
* Added local caching (15 minutes) for the Information shortcode, matching the Events shortcode, so repeat visits to the same content reuse the cached result instead of asking geotour.gr again.
= 1.6.1 =
* Events shortcode now filters by radius on the server instead of downloading Geotour's entire event list to every visitor's browser, and caches the upstream fetch for 15 minutes.
* Removed a stray unused API check on the settings page and fixed the admin Events preview, which had been silently empty.
= 1.6.0 =
* Security: the Information (listings) shortcode, the admin preview, and the shortcode wizard all fetched geotour.gr directly with the API key visible in the page's HTML. All three now go through this plugin's own local proxy endpoint, so the key stays server-side and is never sent to visitors.
* Added a Content Language setting (site-wide) so the Information shortcode can request Greek (or English) listings content from Geotour; more languages can be added as Geotour adds them.
* Events shortcode continues to require no API key and stays in English for now.
= 1.5.0 =
* Implemented distinct information access levels (Level 1 and Level 2) based on the subscription tier data provided by the API endpoint.
* Level 1 Access: Introduced a new "Quick Info" modal for Point of Interest (POI) items, accessible via a "€" overlay button for quick checks on Pricing, Working Hours, and Notes.
* Level 2 Access: Added robust support for complete location details, handled via a rich Lightbox Explorer modal featuring an image gallery slider and fully-formatted extended descriptions.
* Added an interactive, tabbed display for location Price, Working Hours, and Special Notes sourced directly from nested Geotour REST API parameters.
* Re-engineered the layout to use a globally centered modal window, fixing CSS grid clipping issues and ensuring proper behavior on mobile devices.
* SCSS refactoring: split large frontend stylesheets into modular components for improved future maintainability.
* Enhanced popup typography and visual scale for dramatically better readability.
= 1.4.1 =
* Fix issues that prevented the fetching of the proper number of items from the Geotour REST endpoint
= 1.4.0 =
* Added the ability to change the default map location of the wizard in the admin page
= 1.3.0 =
* Significant changes in the wizard styling to provide a more user friendly experience
= 1.2.1 =
* Minor fixes and styling of the admin page
= 1.2.0 =
* Improved admin pages. A wizard is added to generate the shortcodes.
= 1.1.2 =
* Minor fixes
* Improvement of the admin page 
= 1.1.1 =
* Minor fixes
= 1.1.0 =
* Add shortcode to add events to the hosting website. No API key is needed for this.
= 1.0.2 =
* Minor fixes
= 1.0.1 =
* CSS changes to improve grid items response to the parent container in order to be used in a variety of scenarios, even in sidebars
* Improvement of the admin page 
= 1.0.0 =
* Initial release.

== TODO ==
* Location details: Show detailed information about specific locations, including descriptions, images, and contact details.
* Add an include and exclude parameters to force exclude or include a particular place, despite the distance from the position set in the lat and lon


== Under Consideration ==
* Alternative way to serve one location with extended text and a photo gallery
